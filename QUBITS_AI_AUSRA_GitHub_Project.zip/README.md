# QUBITS AI AUŠRA

Site editorial de **QALQON NEWS / MAGEN HADASHOT**.

## Estrutura

- `index.html` — página principal
- `book/` — PDF integral
- `editorial/` — manifesto
- `audit/` — auditoria e change log
- `docs/` — deployment
- `web/css/` — estilos
- `.github/workflows/pages.yml` — publicação GitHub Pages
