# Change Log

- Substituída a landing page genérica por uma página editorial.
- Adicionado o PDF integral do livro.
- Adicionada documentação editorial.
- Adicionada auditoria do pacote.
- Adicionado workflow de GitHub Pages.
- Adicionado CSS de produção.
