# Repository Audit

- Página inicial editorial criada em `index.html`.
- PDF integral preservado em `book/QUBITS_AI_AUSRA_full.pdf`.
- CSS de produção criado em `web/css/styles.css`.
- Manifesto e documentação editorial incluídos.
- Workflow de GitHub Pages incluído.
- Caminhos do site são relativos.
- A publicação efectiva ainda depende de enviar estes ficheiros ao GitHub e activar GitHub Pages via GitHub Actions.
