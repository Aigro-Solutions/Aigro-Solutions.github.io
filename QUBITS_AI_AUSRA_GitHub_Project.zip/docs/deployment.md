# Deployment

1. Envie todo o conteúdo deste pacote para o repositório.
2. Faça commit e push para a branch de produção.
3. Abra **Settings → Pages** no GitHub.
4. Seleccione **GitHub Actions** como source.
5. Aguarde o workflow **Deploy static site to GitHub Pages**.
6. Abra a URL apresentada pelo GitHub Pages.
